﻿using static Sitecore.Configuration.Settings;

namespace EMAAR.ECM.Foundation.Search.Settings
{
    public static class SitecoreSettings
    {
        /// <summary>
        /// PlaceholdersToSearch
        /// </summary>
        public static string PlaceholdersToSearch { get; set; } = GetSetting("EMAAR.ECM.Foundation.SitecoreExtensions.PlaceholdersToSearch");

        /// <summary>
        /// BasePageTemplateId
        /// </summary>
        public static string BasePageTemplateId { get; set; } = GetSetting("EMAAR.ECM.Foundation.SitecoreExtensions.BasePageTemplateId");
    }
}